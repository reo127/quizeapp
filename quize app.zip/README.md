<h1 align="center">Quiz-Application</h1> 
 

> In this Quiz Application, users can respond to the quiz questions, and the quiz can be retaken after getting their responses. 

> This Quiz Application is compatible with mobile devices.


# 📝 Features 
✅ This is a quiz application website. <br>
✅ Each question is alloted 15 seconds, where user has to complete the quiz before time. 

# 💻 Technologies used
<img src="https://img.shields.io/badge/HTML5-FF3300?style=for-the-badge&logo=html5&logoColor=white">
<img src="https://img.shields.io/badge/CSS3-0066FF?style=for-the-badge&logo=css3&logoColor=white">
<img src="https://img.shields.io/badge/JavaScript-FFF600?style=for-the-badge&logo=javascript&logoColor=white">

# 👩‍💻 IDE used
<img src="https://img.shields.io/badge/Visual_Studio_Code-0078D4?style=for-the-badge&logo=visual%20studio%20code&logoColor=white">


